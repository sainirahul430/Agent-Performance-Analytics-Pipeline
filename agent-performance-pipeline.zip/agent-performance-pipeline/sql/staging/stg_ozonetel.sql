-- =============================================================================
-- stg_ozonetel.sql
-- Purpose : Normalise raw Ozonetel API response into unified schema
--           so it can be UNION ALL'd with other dialers cleanly.
-- Author  : Rahul Saini
-- =============================================================================

SELECT
  CAST(call_uuid AS STRING)                           AS call_id,
  CAST(agent_login_id AS STRING)                      AS agent_id,
  TRIM(agent_name)                                    AS agent_name,
  'OZONETEL'                                          AS dialer_source,

  -- Normalise timestamp (Ozonetel sends IST as string)
  PARSE_TIMESTAMP('%Y-%m-%d %H:%M:%S', start_time)   AS call_timestamp,

  -- Normalise status labels to unified schema
  CASE
    WHEN disposition IN ('ANSWERED', 'CONNECTED', 'SUCCESS') THEN 'CONNECTED'
    WHEN disposition IN ('NO_ANSWER', 'NOANSWER', 'UNANSWERED') THEN 'NOT_CONNECTED'
    WHEN disposition IN ('BUSY', 'USER_BUSY') THEN 'BUSY'
    ELSE 'OTHER'
  END                                                 AS call_status,

  CAST(duration AS INT64)                             AS call_duration_seconds,
  CAST(talk_time AS INT64)                            AS talk_time_seconds,

  -- Ozonetel stores break as separate table — joined here
  COALESCE(CAST(b.break_seconds AS INT64), 0)         AS break_duration_seconds

FROM `project.raw.ozonetel_calls` c
LEFT JOIN `project.raw.ozonetel_breaks` b
  ON c.agent_login_id = b.agent_login_id
  AND DATE(PARSE_TIMESTAMP('%Y-%m-%d %H:%M:%S', c.start_time))
    = DATE(PARSE_TIMESTAMP('%Y-%m-%d %H:%M:%S', b.break_date))

WHERE start_time IS NOT NULL
  AND agent_login_id IS NOT NULL;
