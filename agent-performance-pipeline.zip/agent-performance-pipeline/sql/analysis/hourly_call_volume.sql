-- =============================================================================
-- hourly_call_volume.sql
-- Purpose : Intraday call distribution per agent — feeds the hourly heatmap
--           in Looker Studio. Helps identify peak hours and idle periods.
-- Author  : Rahul Saini
-- =============================================================================

WITH hourly AS (
  SELECT
    agent_id,
    agent_name,
    dialer_source,
    DATE(call_timestamp)              AS call_date,
    EXTRACT(HOUR FROM call_timestamp) AS call_hour,

    COUNT(call_id)                    AS calls_in_hour,
    COUNTIF(call_status = 'CONNECTED') AS connected_in_hour,
    ROUND(SUM(talk_time_seconds)/60.0, 1) AS talk_minutes_in_hour

  FROM (
    SELECT * FROM `project.agent_analytics.stg_ozonetel`
    UNION ALL
    SELECT * FROM `project.agent_analytics.stg_smartflo`
    UNION ALL
    SELECT * FROM `project.agent_analytics.stg_exotel`
    UNION ALL
    SELECT * FROM `project.agent_analytics.stg_avyukta`
  )
  WHERE DATE(call_timestamp) = CURRENT_DATE()
    AND EXTRACT(HOUR FROM call_timestamp) BETWEEN 9 AND 20  -- shift hours
  GROUP BY 1, 2, 3, 4, 5
),

with_running_total AS (
  SELECT
    *,
    -- Cumulative calls through the day per agent
    SUM(calls_in_hour) OVER (
      PARTITION BY agent_id, call_date
      ORDER BY call_hour
      ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    )                                 AS cumulative_calls,

    -- Hour-over-hour call velocity change
    calls_in_hour - LAG(calls_in_hour) OVER (
      PARTITION BY agent_id, call_date
      ORDER BY call_hour
    )                                 AS calls_change_from_prev_hour

  FROM hourly
)

SELECT
  agent_name,
  dialer_source,
  call_hour,
  calls_in_hour,
  connected_in_hour,
  talk_minutes_in_hour,
  cumulative_calls,
  calls_change_from_prev_hour,
  -- Label for heatmap colouring
  CASE
    WHEN calls_in_hour >= 15 THEN 'HIGH'
    WHEN calls_in_hour BETWEEN 8 AND 14 THEN 'MEDIUM'
    ELSE 'LOW'
  END                                 AS activity_band
FROM with_running_total
ORDER BY agent_name, call_hour;
