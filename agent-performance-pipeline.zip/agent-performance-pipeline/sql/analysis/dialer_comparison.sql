-- =============================================================================
-- dialer_comparison.sql
-- Purpose : Cross-dialer connectivity benchmarking — which dialer is performing
--           best in real time. Used by Sales Head to route agents to best dialer.
-- Author  : Rahul Saini
-- =============================================================================

WITH dialer_stats AS (
  SELECT
    dialer_source,
    DATE(call_timestamp)                                        AS call_date,
    EXTRACT(HOUR FROM call_timestamp)                          AS call_hour,

    COUNT(call_id)                                             AS total_calls,
    COUNTIF(call_status = 'CONNECTED')                         AS connected_calls,

    ROUND(COUNTIF(call_status = 'CONNECTED') * 100.0
          / NULLIF(COUNT(call_id), 0), 2)                     AS connectivity_pct,

    ROUND(AVG(call_duration_seconds) / 60.0, 1)               AS avg_call_duration_min,
    COUNT(DISTINCT agent_id)                                   AS active_agents

  FROM (
    SELECT * FROM `project.agent_analytics.stg_ozonetel`
    UNION ALL
    SELECT * FROM `project.agent_analytics.stg_smartflo`
    UNION ALL
    SELECT * FROM `project.agent_analytics.stg_exotel`
    UNION ALL
    SELECT * FROM `project.agent_analytics.stg_avyukta`
  )
  WHERE DATE(call_timestamp) = CURRENT_DATE()
  GROUP BY 1, 2, 3
),

ranked AS (
  SELECT
    *,
    -- Which dialer has best connectivity this hour?
    RANK() OVER (
      PARTITION BY call_date, call_hour
      ORDER BY connectivity_pct DESC
    )                                                          AS hourly_connectivity_rank,

    -- Running average connectivity across the day per dialer
    AVG(connectivity_pct) OVER (
      PARTITION BY dialer_source, call_date
      ORDER BY call_hour
      ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    )                                                          AS running_avg_connectivity

  FROM dialer_stats
)

SELECT
  dialer_source,
  call_hour,
  total_calls,
  connected_calls,
  connectivity_pct,
  avg_call_duration_min,
  active_agents,
  hourly_connectivity_rank,
  ROUND(running_avg_connectivity, 2)                           AS running_avg_connectivity,
  CASE
    WHEN hourly_connectivity_rank = 1 THEN '🟢 BEST THIS HOUR'
    WHEN hourly_connectivity_rank = 2 THEN '🟡 SECOND'
    ELSE '🔴 UNDERPERFORMING'
  END                                                          AS dialer_status
FROM ranked
ORDER BY call_hour DESC, hourly_connectivity_rank ASC;
