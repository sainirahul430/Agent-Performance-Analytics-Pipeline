-- =============================================================================
-- agent_daily_scorecard.sql
-- Purpose : Per-agent daily KPIs with ranking, lag comparison, and flags
-- Author  : Rahul Saini
-- Refresh : Every 3 hours via BigQuery Scheduled Query
-- =============================================================================

WITH base AS (
  -- Combine all 4 dialers into one unified view
  SELECT * FROM `project.agent_analytics.stg_ozonetel`
  UNION ALL
  SELECT * FROM `project.agent_analytics.stg_smartflo`
  UNION ALL
  SELECT * FROM `project.agent_analytics.stg_exotel`
  UNION ALL
  SELECT * FROM `project.agent_analytics.stg_avyukta`
),

agent_daily AS (
  SELECT
    agent_id,
    agent_name,
    dialer_source,
    DATE(call_timestamp)                                      AS call_date,

    -- Volume metrics
    COUNT(call_id)                                            AS total_calls,
    COUNTIF(call_status = 'CONNECTED')                        AS connected_calls,
    ROUND(COUNTIF(call_status = 'CONNECTED') * 100.0
          / NULLIF(COUNT(call_id), 0), 2)                    AS connectivity_pct,

    -- Time metrics (in minutes)
    ROUND(SUM(talk_time_seconds) / 60.0, 1)                  AS talk_time_minutes,
    ROUND(SUM(break_duration_seconds) / 60.0, 1)             AS break_duration_minutes,

    -- Efficiency index: rewards high calls + connectivity, penalises long breaks
    ROUND(
      (COUNT(call_id) * (COUNTIF(call_status = 'CONNECTED') * 1.0
       / NULLIF(COUNT(call_id), 0)))
      / NULLIF(SUM(break_duration_seconds) / 3600.0, 0),
    2)                                                        AS efficiency_index

  FROM base
  GROUP BY 1, 2, 3, 4
),

with_lag AS (
  SELECT
    *,
    -- Day-over-day talk time trend
    LAG(talk_time_minutes) OVER (
      PARTITION BY agent_id
      ORDER BY call_date
    )                                                         AS prev_day_talk_time,

    -- Day-over-day call count trend
    LAG(total_calls) OVER (
      PARTITION BY agent_id
      ORDER BY call_date
    )                                                         AS prev_day_calls,

    -- Rank agents within each date by efficiency
    RANK() OVER (
      PARTITION BY call_date
      ORDER BY efficiency_index DESC
    )                                                         AS efficiency_rank,

    -- Rank by connectivity % within each date
    RANK() OVER (
      PARTITION BY call_date
      ORDER BY connectivity_pct DESC
    )                                                         AS connectivity_rank

  FROM agent_daily
),

final AS (
  SELECT
    *,
    -- WoW talk time change %
    ROUND(
      (talk_time_minutes - prev_day_talk_time)
      / NULLIF(prev_day_talk_time, 0) * 100, 1
    )                                                         AS talk_time_change_pct,

    -- Performance flags for leadership dashboard
    CASE
      WHEN total_calls < 20
        THEN 'LOW_CALLS'
      WHEN connectivity_pct < 40
        THEN 'LOW_CONNECTIVITY'
      WHEN break_duration_minutes > 90
        THEN 'EXCESS_BREAK'
      WHEN efficiency_index < 5
        THEN 'LOW_EFFICIENCY'
      ELSE 'NORMAL'
    END                                                       AS performance_flag

  FROM with_lag
)

SELECT * FROM final
ORDER BY call_date DESC, efficiency_rank ASC;
