# Setup Guide

## Prerequisites

- Google Cloud project with BigQuery enabled
- API credentials for each dialer (see Environment Variables section)
- Python 3.9+
- Looker Studio account (free)

## Step 1 — BigQuery Setup

```sql
-- Create the dataset
CREATE SCHEMA `your_project.agent_analytics`
OPTIONS (location = 'asia-south1');  -- Mumbai region for low latency
```

## Step 2 — Environment Variables

Create a `.env` file (never commit this to GitHub):

```
GCP_PROJECT_ID=your-gcp-project
OZONETEL_API_KEY=xxx
SMARTFLO_TOKEN=xxx
EXOTEL_SID=xxx
EXOTEL_API_KEY=xxx
EXOTEL_API_TOKEN=xxx
AVYUKTA_API_KEY=xxx
```

## Step 3 — Install Dependencies

```bash
pip install -r python/requirements.txt
```

## Step 4 — Run Staging Tables

Run these SQL files in order in BigQuery:

1. `sql/staging/stg_ozonetel.sql`
2. `sql/staging/stg_smartflo.sql`
3. `sql/staging/stg_exotel.sql`
4. `sql/staging/stg_avyukta.sql`

## Step 5 — Run Analysis Views

```
sql/analysis/agent_daily_scorecard.sql   → Save as BigQuery View
sql/analysis/dialer_comparison.sql       → Save as BigQuery View
sql/analysis/hourly_call_volume.sql      → Save as BigQuery View
sql/analysis/low_efficiency_flags.sql    → Save as BigQuery View
```

## Step 6 — Schedule the Python Ingestion

Option A — Google Apps Script (recommended):
- Deploy `python/apps_script_trigger.js` in Google Apps Script
- Set a time-based trigger: every 3 hours

Option B — Cloud Scheduler + Cloud Run:
- Containerise `ingest_dialers.py`
- Set Cloud Scheduler job: `0 */3 * * *`

## Step 7 — Connect Looker Studio

1. Open [Looker Studio](https://lookerstudio.google.com)
2. Add data source → BigQuery
3. Select `agent_analytics.agent_daily_scorecard` view
4. Build charts using metrics: `total_calls`, `connectivity_pct`, `efficiency_rank`, `performance_flag`

See `dashboard/looker_data_sources.md` for the exact field mappings used.
