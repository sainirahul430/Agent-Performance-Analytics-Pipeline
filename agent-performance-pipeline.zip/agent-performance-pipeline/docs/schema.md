# BigQuery Table Schemas

## Unified Staging Schema

All 4 dialer staging tables (`stg_ozonetel`, `stg_smartflo`, `stg_exotel`, `stg_avyukta`) share this schema so they can be UNION ALL'd cleanly.

| Column | Type | Description |
|---|---|---|
| `call_id` | STRING | Unique call identifier from source dialer |
| `agent_id` | STRING | Agent login ID |
| `agent_name` | STRING | Full name as configured in dialer |
| `dialer_source` | STRING | One of: OZONETEL, TATA_SMARTFLO, EXOTEL, AVYUKTA |
| `call_timestamp` | TIMESTAMP | Call start time (IST) |
| `call_status` | STRING | Normalised: CONNECTED / NOT_CONNECTED / BUSY / OTHER |
| `call_duration_seconds` | INT64 | Total call duration including ringing |
| `talk_time_seconds` | INT64 | Connected talk time only |
| `break_duration_seconds` | INT64 | Agent break time in same period |

---

## agent_daily_scorecard (Analysis View)

| Column | Type | Description |
|---|---|---|
| `agent_id` | STRING | Agent identifier |
| `agent_name` | STRING | Agent full name |
| `call_date` | DATE | Date of activity |
| `dialer_source` | STRING | Primary dialer used that day |
| `total_calls` | INT64 | Total outbound calls |
| `connected_calls` | INT64 | Successfully connected calls |
| `connectivity_pct` | FLOAT64 | % of calls connected |
| `talk_time_minutes` | FLOAT64 | Total talk time in minutes |
| `break_duration_minutes` | FLOAT64 | Total break time in minutes |
| `efficiency_index` | FLOAT64 | Composite KPI score |
| `efficiency_rank` | INT64 | Rank among all agents on that date |
| `prev_day_calls` | INT64 | Previous day's call count (via LAG) |
| `talk_time_change_pct` | FLOAT64 | Day-over-day talk time % change |
| `performance_flag` | STRING | LOW_CALLS / LOW_CONNECTIVITY / EXCESS_BREAK / LOW_EFFICIENCY / NORMAL |
