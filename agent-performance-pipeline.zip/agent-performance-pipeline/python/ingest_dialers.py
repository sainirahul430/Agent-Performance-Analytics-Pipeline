"""
ingest_dialers.py
-----------------
Pulls call data from all 4 dialer APIs (Ozonetel, TATA Smartflo, Exotel, Avyukta)
and loads into Google BigQuery staging tables.

Runs every 3 hours via Google Apps Script time-based trigger.

Author : Rahul Saini
"""

import os
import requests
import pandas as pd
from datetime import datetime, timedelta
from google.cloud import bigquery

# ── Config ─────────────────────────────────────────────────────────────────────
PROJECT_ID  = os.environ["GCP_PROJECT_ID"]
DATASET     = "agent_analytics"
BQ_CLIENT   = bigquery.Client(project=PROJECT_ID)

# Fetch last 4 hours to ensure no gaps between refreshes
SINCE       = datetime.now() - timedelta(hours=4)
SINCE_STR   = SINCE.strftime("%Y-%m-%d %H:%M:%S")

# ── Shared schema (all dialers normalised to this) ─────────────────────────────
UNIFIED_SCHEMA = [
    "call_id", "agent_id", "agent_name", "dialer_source",
    "call_timestamp", "call_status", "call_duration_seconds",
    "talk_time_seconds", "break_duration_seconds"
]

# ── Ozonetel ───────────────────────────────────────────────────────────────────
def fetch_ozonetel() -> pd.DataFrame:
    url    = "https://api.ozonetel.com/ca/api/CallLogs"
    params = {
        "api_key"   : os.environ["OZONETEL_API_KEY"],
        "from_date" : SINCE_STR,
        "to_date"   : datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "format"    : "json"
    }
    resp = requests.get(url, params=params, timeout=30)
    resp.raise_for_status()
    df = pd.DataFrame(resp.json().get("data", []))

    return pd.DataFrame({
        "call_id"               : df["call_uuid"].astype(str),
        "agent_id"              : df["agent_login_id"].astype(str),
        "agent_name"            : df["agent_name"].str.strip(),
        "dialer_source"         : "OZONETEL",
        "call_timestamp"        : pd.to_datetime(df["start_time"]),
        "call_status"           : df["disposition"].map({
                                    "ANSWERED": "CONNECTED",
                                    "NO_ANSWER": "NOT_CONNECTED",
                                    "BUSY": "BUSY"
                                  }).fillna("OTHER"),
        "call_duration_seconds" : pd.to_numeric(df["duration"], errors="coerce").fillna(0).astype(int),
        "talk_time_seconds"     : pd.to_numeric(df["talk_time"], errors="coerce").fillna(0).astype(int),
        "break_duration_seconds": 0  # fetched separately via SQL join
    })


# ── TATA Smartflo ──────────────────────────────────────────────────────────────
def fetch_smartflo() -> pd.DataFrame:
    url     = "https://smartflo.tatateleservices.com/v1/call/logs"
    headers = {"Authorization": f"Bearer {os.environ['SMARTFLO_TOKEN']}"}
    params  = {"from": SINCE_STR, "limit": 1000}
    resp    = requests.get(url, headers=headers, params=params, timeout=30)
    resp.raise_for_status()
    df = pd.DataFrame(resp.json().get("records", []))

    return pd.DataFrame({
        "call_id"               : df["id"].astype(str),
        "agent_id"              : df["agent_id"].astype(str),
        "agent_name"            : df["agent_name"].str.strip(),
        "dialer_source"         : "TATA_SMARTFLO",
        "call_timestamp"        : pd.to_datetime(df["start_time"]),
        "call_status"           : df["status"].map({
                                    "answered": "CONNECTED",
                                    "no-answer": "NOT_CONNECTED",
                                    "busy": "BUSY"
                                  }).fillna("OTHER"),
        "call_duration_seconds" : pd.to_numeric(df["duration"], errors="coerce").fillna(0).astype(int),
        "talk_time_seconds"     : pd.to_numeric(df["bill_duration"], errors="coerce").fillna(0).astype(int),
        "break_duration_seconds": pd.to_numeric(df.get("break_time", 0), errors="coerce").fillna(0).astype(int)
    })


# ── Exotel ─────────────────────────────────────────────────────────────────────
def fetch_exotel() -> pd.DataFrame:
    sid     = os.environ["EXOTEL_SID"]
    key     = os.environ["EXOTEL_API_KEY"]
    token   = os.environ["EXOTEL_API_TOKEN"]
    url     = f"https://api.exotel.com/v1/Accounts/{sid}/Calls.json"
    params  = {"DateCreated[gte]": SINCE_STR, "Limit": 500}
    resp    = requests.get(url, auth=(key, token), params=params, timeout=30)
    resp.raise_for_status()
    df = pd.DataFrame(resp.json().get("Calls", []))

    return pd.DataFrame({
        "call_id"               : df["Sid"].astype(str),
        "agent_id"              : df["To"].astype(str),           # agent phone as ID
        "agent_name"            : df.get("CustomField", "Unknown"),
        "dialer_source"         : "EXOTEL",
        "call_timestamp"        : pd.to_datetime(df["StartTime"]),
        "call_status"           : df["Status"].map({
                                    "completed"  : "CONNECTED",
                                    "no-answer"  : "NOT_CONNECTED",
                                    "busy"       : "BUSY",
                                    "failed"     : "OTHER"
                                  }).fillna("OTHER"),
        "call_duration_seconds" : pd.to_numeric(df["Duration"], errors="coerce").fillna(0).astype(int),
        "talk_time_seconds"     : pd.to_numeric(df["Duration"], errors="coerce").fillna(0).astype(int),
        "break_duration_seconds": 0
    })


# ── Avyukta ────────────────────────────────────────────────────────────────────
def fetch_avyukta() -> pd.DataFrame:
    url     = "https://api.avyukta.ai/cdr/fetch"
    headers = {"x-api-key": os.environ["AVYUKTA_API_KEY"]}
    payload = {"from_datetime": SINCE_STR}
    resp    = requests.post(url, headers=headers, json=payload, timeout=30)
    resp.raise_for_status()
    df = pd.DataFrame(resp.json().get("cdr_data", []))

    return pd.DataFrame({
        "call_id"               : df["unique_id"].astype(str),
        "agent_id"              : df["agent_id"].astype(str),
        "agent_name"            : df["agent_name"].str.strip(),
        "dialer_source"         : "AVYUKTA",
        "call_timestamp"        : pd.to_datetime(df["call_start"]),
        "call_status"           : df["hangup_cause"].map({
                                    "NORMAL_CLEARING": "CONNECTED",
                                    "NO_ANSWER"      : "NOT_CONNECTED",
                                    "USER_BUSY"      : "BUSY"
                                  }).fillna("OTHER"),
        "call_duration_seconds" : pd.to_numeric(df["duration"], errors="coerce").fillna(0).astype(int),
        "talk_time_seconds"     : pd.to_numeric(df["billsec"], errors="coerce").fillna(0).astype(int),
        "break_duration_seconds": pd.to_numeric(df.get("break_time", 0), errors="coerce").fillna(0).astype(int)
    })


# ── Load to BigQuery ───────────────────────────────────────────────────────────
def load_to_bigquery(df: pd.DataFrame, table_name: str):
    table_ref = f"{PROJECT_ID}.{DATASET}.{table_name}"
    job_config = bigquery.LoadJobConfig(
        write_disposition=bigquery.WriteDisposition.WRITE_APPEND,
        schema_update_options=[bigquery.SchemaUpdateOption.ALLOW_FIELD_ADDITION],
        autodetect=True
    )
    job = BQ_CLIENT.load_table_from_dataframe(df, table_ref, job_config=job_config)
    job.result()
    print(f"  ✓ Loaded {len(df):,} rows → {table_ref}")


# ── Main ───────────────────────────────────────────────────────────────────────
def main():
    print(f"\n{'='*60}")
    print(f"Dialer ingestion run — {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print(f"Fetching records since: {SINCE_STR}")
    print(f"{'='*60}\n")

    tasks = [
        (fetch_ozonetel,  "raw_ozonetel"),
        (fetch_smartflo,  "raw_smartflo"),
        (fetch_exotel,    "raw_exotel"),
        (fetch_avyukta,   "raw_avyukta"),
    ]

    for fetch_fn, table in tasks:
        dialer = table.replace("raw_", "").upper()
        try:
            print(f"Fetching {dialer}...")
            df = fetch_fn()
            load_to_bigquery(df, table)
        except Exception as e:
            print(f"  ✗ {dialer} failed: {e}")

    print("\nAll dialers processed. BigQuery views will refresh on next scheduled query run.\n")


if __name__ == "__main__":
    main()
